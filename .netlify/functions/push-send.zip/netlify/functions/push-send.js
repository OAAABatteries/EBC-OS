var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var push_send_exports = {};
__export(push_send_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(push_send_exports);
var import_web_push = __toESM(require("web-push"), 1);
var import_supabase_js = require("@supabase/supabase-js");
const VAPID_PUBLIC = process.env.VAPID_PUBLIC_KEY;
const VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY;
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || "mailto:admin@ebconstructors.com";
const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || "";
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY || "";
const supabase = supabaseUrl && supabaseKey ? (0, import_supabase_js.createClient)(supabaseUrl, supabaseKey) : null;
async function handler(event) {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: corsHeaders() };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers: corsHeaders(), body: "Method Not Allowed" };
  }
  if (!VAPID_PUBLIC || !VAPID_PRIVATE) {
    return {
      statusCode: 500,
      headers: corsHeaders(),
      body: JSON.stringify({ ok: false, message: "VAPID keys not configured" })
    };
  }
  try {
    import_web_push.default.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC, VAPID_PRIVATE);
    const { subscription, userId, title, body, tag, url } = JSON.parse(event.body);
    if (!title) {
      return {
        statusCode: 400,
        headers: corsHeaders(),
        body: JSON.stringify({ ok: false, message: "title required" })
      };
    }
    const payload = JSON.stringify({
      title,
      body: body || "",
      tag: tag || "ebc-notification",
      url: url || "/",
      icon: "/ebc-logo.png"
    });
    if (subscription) {
      await sendToSubscription(subscription, payload);
      return {
        statusCode: 200,
        headers: corsHeaders(),
        body: JSON.stringify({ ok: true, sent: 1 })
      };
    }
    if (userId && supabase) {
      const { data: subs, error } = await supabase.from("push_subscriptions").select("endpoint, keys_p256dh, keys_auth").eq("user_id", userId);
      if (error) {
        console.error("[push] lookup error:", error.message);
        return {
          statusCode: 500,
          headers: corsHeaders(),
          body: JSON.stringify({ ok: false, message: "Failed to look up subscriptions" })
        };
      }
      if (!subs || subs.length === 0) {
        return {
          statusCode: 200,
          headers: corsHeaders(),
          body: JSON.stringify({ ok: true, sent: 0, message: "No subscriptions found for user" })
        };
      }
      let sent = 0;
      const expired = [];
      for (const sub of subs) {
        const pushSub = {
          endpoint: sub.endpoint,
          keys: { p256dh: sub.keys_p256dh, auth: sub.keys_auth }
        };
        try {
          await import_web_push.default.sendNotification(pushSub, payload);
          sent++;
        } catch (err) {
          if (err.statusCode === 410 || err.statusCode === 404) {
            expired.push(sub.endpoint);
          } else {
            console.warn("[push] send error:", err.message);
          }
        }
      }
      if (expired.length > 0 && supabase) {
        await supabase.from("push_subscriptions").delete().in("endpoint", expired);
        console.log(`[push] Cleaned up ${expired.length} expired subscriptions`);
      }
      return {
        statusCode: 200,
        headers: corsHeaders(),
        body: JSON.stringify({ ok: true, sent, expired: expired.length })
      };
    }
    return {
      statusCode: 400,
      headers: corsHeaders(),
      body: JSON.stringify({ ok: false, message: "subscription or userId required" })
    };
  } catch (err) {
    console.error("[push] send failed:", err.message);
    const status = err.statusCode === 410 ? 410 : 500;
    return {
      statusCode: status,
      headers: corsHeaders(),
      body: JSON.stringify({ ok: false, message: err.message })
    };
  }
}
async function sendToSubscription(sub, payload) {
  await import_web_push.default.sendNotification(sub, payload);
}
function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
